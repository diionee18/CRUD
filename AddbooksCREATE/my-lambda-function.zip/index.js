const AWS = require('aws-sdk');
const dynamoClient = new AWS.DynamoDB.DocumentClient({ region: 'eu-north-1' });

exports.handler = async (event) => {
   
    const { BookName, Author } = event.body;

    const params = {
        TableName: 'Books', // Anpassa tabellnamnet till din DynamoDB-tabell
        Item: {
            "BookId": AWS.util.uuid.v4(), // Anpassa nyckelattributet och använd uuid.v4() för att generera ett UUID
            "BookName": BookName, // Anpassa attributnamnet till din DynamoDB-tabell
            "Author": Author // Anpassa attributnamnet till din DynamoDB-tabell
        }
    };

    try {
        await dynamoClient.put(params).promise();
        return {
            statusCode: 201,
            body: ''
        };
    } catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            body: JSON.stringify('Error creating book: ' + error.message)
        };
    }
};

